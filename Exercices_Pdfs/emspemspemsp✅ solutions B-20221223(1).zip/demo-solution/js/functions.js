function outputList(idOutputList, idSelect){
  var olOutput = document.getElementById(idOutputList)
  var list = document.getElementById(idSelect)

  olOutput.innerHTML = ""
  for(var i=0; i<list.length; i++){
    olOutput.innerHTML += "<li>"+list.options[i].value+"</li>"
  }
}

function addList(idInput, idSelect){
  var input = document.getElementById(idInput).value.trim()
  var list = document.getElementById(idSelect)
  list.innerHTML += "<option value='"+input+"'>"+input+"</option>"
}
