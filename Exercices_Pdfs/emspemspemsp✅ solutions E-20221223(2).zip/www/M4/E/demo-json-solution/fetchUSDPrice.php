<?php
  //header("Content-Type: application/json; charset=utf-8");
  echo file_get_contents("https://api.exchangerate-api.com/v4/latest/EUR");
 ?>
