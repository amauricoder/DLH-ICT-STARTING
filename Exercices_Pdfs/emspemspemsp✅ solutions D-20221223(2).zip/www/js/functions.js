function outputList(){
  var olOutput = document.getElementById("olOutput")
  var list = document.getElementById("selArticles")

  olOutput.innerHTML = ""
  for(var i=0; i<list.length; i++){
    olOutput.innerHTML += "<li>"+list.options[i].value+"</li>"
  }
}

function addList(){
  var input = document.getElementById("inArticle").value.trim()
  var list = document.getElementById("selArticles")
  list.innerHTML += "<option value='"+input+"'>"+input+"</option>"
}

function order(beverage, amount){
  alert("Here is your order: "+amount+"x "+beverage)
}
function setBorder(id, color){
  document.getElementById(id).style.border = "1px solid "+color
}
function removeBorder(id){
  document.getElementById(id).style.removeProperty("border")
}
function count(start,end, idDiv){
  document.getElementById(idDiv).innerHTML = "";
  if(start>end){ // avoid variable swap
      for(var i=start; i>=end; i--){
        document.getElementById(idDiv).innerHTML += i + "<br>"
      }
  }
  else{
    for(var i=start; i<=end; i++){
      document.getElementById(idDiv).innerHTML += i + "<br>"
    }
  }
}

function celsius2fahrenheit(degreesC){
  var celsiusF =  32 + degreesC * 9/5;
  return celsiusF
}

function liters2gallons(liters){
  var gallons = liters * 0.2641722;
  return gallons
}

function getRandomNumber(min,max){
  var r = Math.floor(Math.random() * (max-min+1))+min
  return r
}

function isBenelux(country){
  if(country.toLowerCase()=="luxembourg" || country.toLowerCase()=="netherlands" || country.toLowerCase()=="belgium"){
    return true
  }
  else{
    return false
  }
}

function fillList(arr, idList){
  document.getElementById(idList).innerHTML = ""
  for(var i=0; i<arr.length; i++){
    document.getElementById(idList).innerHTML += "<option value=''>"+arr[i]+"</option>"
  }
}

function findIndex(arr, value){
  if(arr.length==0){
    return -1
  }
  else{
    for(var i=0; i<arr.length; i++){
      if(arr[i]==value){
        return i
      }
    }
    return -1
  }
}
