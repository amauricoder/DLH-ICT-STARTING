function outputList(){
  var olOutput = document.getElementById("olOutput")
  var list = document.getElementById("selStudents")

  olOutput.innerHTML = ""
  for(var i=0; i<list.length; i++){
    olOutput.innerHTML += "<li>"+list.options[i].value+"</li>"
  }
}

function addList(){
  var input = document.getElementById("inStudent").value.trim()
  var list = document.getElementById("selStudents")
  list.innerHTML += "<option value='"+input+"'>"+input+"</option>"
}
