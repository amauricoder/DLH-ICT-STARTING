function hello(){
  console.log("Hello!");
}
function bye(){
  console.log("Bye");
}
function ask(){
  console.log("How are you?");
}
function ok(){
  console.log("ok");
}
